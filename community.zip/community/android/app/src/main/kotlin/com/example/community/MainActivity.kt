package com.example.community

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
